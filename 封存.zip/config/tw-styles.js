const styles = {
  fontFamily: {
    body: ["'Open Sans',-apple-system", "BlinkMacSystemFont", "PingFang SC", "sans-serif"],
  },
}

module.exports = styles
