"use strict";
(() => {
var exports = {};
exports.id = 894;
exports.ids = [894];
exports.modules = {

/***/ 9943:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ProductDetail)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/imageCarousel.tsx


const ImageCarousel = ({ images  })=>{
    const [selectedImage, setSelectedImage] = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        if (images && images[0]) {
            setSelectedImage(images[0]);
        }
    }, [
        images
    ]);
    const handleSelectedImageChange = (newIdx)=>{
        if (images && images.length > 0) {
            setSelectedImage(images[newIdx]);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mx-auto px-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "max-w-[350px] h-[350px] mb-2 bg-no-repeat bg-contain bg-center md:max-w-[500px] md:h-[500px]",
                style: {
                    backgroundImage: `url(${selectedImage?.url})`
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex max-w-full overflow-x-hidden space-x-2",
                    children: images && images.map((image, idx)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            onClick: ()=>handleSelectedImageChange(idx),
                            style: {
                                backgroundImage: `url(${image.url})`
                            },
                            className: "h-[70px] min-w-[70px] bg-no-repeat bg-contain bg-center md:h-[100px] md:min-w-[100px] cursor-pointer"
                        }, image.id))
                })
            })
        ]
    });
};
/* harmony default export */ const imageCarousel = (ImageCarousel);

;// CONCATENATED MODULE: ./container/ProductDetail/index.tsx



const Product = ({ resource  })=>{
    const router = (0,router_.useRouter)();
    const { slug  } = router.query;
    const { targetProduct , tags  } = resource;
    const carousel = targetProduct[0]?.items.map((x, index)=>({
            id: index,
            url: x.sliderimage.url
        }));
    console.log("tags", tags);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "px-4 min-h-[800px] mt-[120px] lg:pt-14 lg:pl-28 lg:pr-40 flex justify-center mb-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[200px] max-w-[300px] border border-white hidden mt-[84px] mr-[50px] xl:block text-white",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "space-y-4 mt-10 ml-4 cursor-pointer",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            id: "all",
                            onClick: ()=>router.push(`/product/all`),
                            children: "．全部商品．"
                        }),
                        tags.results.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                id: tag.id,
                                onClick: ()=>router.push(`/product/${tag.uid}`),
                                children: `．${tag.data?.tagname[0].text}．`
                            }))
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "lg:min-w-[800px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "flex flex-row flex-wrap justify-end mt-10 text-white w-[300px] sm:w-full space-x-2 xl:hidden",
                        children: [
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                id: "all",
                                onClick: ()=>router.push(`/product/all`),
                                children: "全部商品"
                            }),
                            tags.results.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    id: tag.id,
                                    onClick: ()=>router.push(`/product/${tag.uid}`),
                                    children: ` / ${tag.data?.tagname[0].text}`
                                }))
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col space-y-6 mt-4 md:flex-row md:space-x-6 md:items-end w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(imageCarousel, {
                                images: carousel
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "space-y-2 mx-8",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-white flex space-x-4 items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-white text-[20px] font-bold",
                                                children: targetProduct[0].primary.title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: targetProduct[0].primary.description
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-white font-bold",
                                        children: targetProduct[0].primary.price
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex flex-wrap justify-start",
                                        children: targetProduct[0].items.map((x)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "bg-white rounded-sm py-1 px-3 mt-2 mr-2",
                                                children: x.category[0].text
                                            }))
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ProductDetail = (Product);


/***/ }),

/***/ 847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_prismic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3899);
/* harmony import */ var _components_template__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6488);
/* harmony import */ var _container_ProductDetail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9943);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(848);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_prismic__WEBPACK_IMPORTED_MODULE_1__]);
_lib_prismic__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-nocheck





const Index = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_template__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            header: data,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container_ProductDetail__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                resource: data
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);
async function getStaticProps({ preview =false , previewData , params  }) {
    const client = (0,_lib_prismic__WEBPACK_IMPORTED_MODULE_1__/* .createClient */ .e)({
        previewData
    });
    const headerImg = await client.getByUID("header", "logo");
    const products = await client.getByUID("productpost", "product");
    const tags = await client.getByType("producttag");
    const targetProduct = products.data.slices?.filter((el)=>el.primary.productuid === params.id);
    return {
        props: {
            data: {
                headerImg,
                targetProduct,
                tags
            }
        }
    };
}
async function getStaticPaths() {
    const client = (0,_lib_prismic__WEBPACK_IMPORTED_MODULE_1__/* .createClient */ .e)();
    const products = await client.getByUID("productpost", "product");
    return {
        paths: products?.data.slices.map((x)=>`/product/p/${x.primary.productuid}`),
        fallback: false
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 7444:
/***/ ((module) => {

module.exports = require("next/dist/server/web/spec-extension/cookies/index.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4582:
/***/ ((module) => {

module.exports = import("@prismicio/client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,122,676,664,899,0], () => (__webpack_exec__(847)));
module.exports = __webpack_exports__;

})();