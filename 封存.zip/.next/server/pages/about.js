"use strict";
(() => {
var exports = {};
exports.id = 521;
exports.ids = [521];
exports.modules = {

/***/ 652:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ container_Main)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/main.tsx


const Main = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full mt-[120px] lg:flex lg:flex-row lg:px-[50px] lg:justify-between lg:min-h-[700px] mb-[120px]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-white py-[100px] tracking-[6px] lg:py-[150px] lg:pl-[50px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[28px] font-medium w-[320px] m-auto xl:text-[40px] xl:w-[450px]",
                        children: "傳統派報 x 平面設計"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-start w-[320px] m-auto mt-[28px] xl:text-xl xl:w-[450px] space-y-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: "從設計到派發"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: "我們要讓您的設計貼滿大街小巷"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col space-y-4 px-6 min-h-[360px] max-w-[400px] m-auto lg:max-w-[500px] lg:scale-[1.15] lg:ml-[100px] xl:scale-[1.35] xl:ml-[300px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex w-full space-x-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "blockanimation min-w-[120px] min-h-[150px] relative bg-[url('/images/main-block1.svg')] bg-cover cursor-pointer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-[110px] w-[110px] pl-[16px] pt-[10px] tracking-widest text-white absolute top-[15%] left-[30px] border-white border-l ",
                                    children: "作品集"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "blockanimation min-w-[120px] min-h-[150px] relative main-block2 cursor-pointer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "h-[110px] w-[110px] pl-[16px] pt-[10px] tracking-widest text-white absolute top-[15%] left-[30px] border-white border-l",
                                    children: "聯絡我們"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "min-h-[150px] min-w-[300px] relative main-block3 ",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "h-[110px] w-[110px] pl-[16px] pt-[10px] tracking-widest text-white absolute top-[15%] right-[10px] border-white border-l",
                            children: [
                                "派報 x 設計",
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-sm mt-5",
                                    children: "整合式廣告介紹"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const main = (Main);

// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
;// CONCATENATED MODULE: ./components/history.tsx



const History = ({ text  })=>{
    const content = (0,external_lodash_.get)(text, "data.slices");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute w-full h-full top-0 text-center bg-[#26292db1] opacity-80"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-[url('/images/history.jpg')] bg-cover z-30 h-[800px] flex justify-center items-center lg:justify-end",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "border-2 border-white h-[700px] w-[80%] z-10 break-words flex items-end lg:w-[45%] lg:mr-[120px]",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-white w-full p-6 space-y-10",
                        children: (0,external_lodash_.map)(content, (x)=>{
                            const target = (0,external_lodash_.get)(x, "primary.text[0].text");
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: target
                            });
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const components_history = (History);

// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./components/slider.tsx


const settings = {
    infinite: true,
    slidesToShow: 7,
    slidesToScroll: 1,
    autoplay: true,
    speed: 2500,
    autoplaySpeed: 2500,
    cssEase: "linear",
    arrows: false,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 3,
                initialSlide: 3
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                initialSlide: 1
            }
        }
    ]
};
const CustomSlider = ({ logo  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
        ...settings,
        children: logo.map((x, index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "hover:scale-[1.15] ease-out duration-300 cursor-pointer rounded-xl min-h-[150px] !flex justify-center items-center ",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    alt: x.repeatimage?.description,
                    src: x.repeatimage.url,
                    className: "p-4 max-h-[120px] max-w-[120px]"
                })
            }, index);
        })
    });
};
/* harmony default export */ const slider = (CustomSlider);

;// CONCATENATED MODULE: ./components/sliderSection.tsx




function SliderSection({ logo  }) {
    const target = (0,external_lodash_.get)(logo, "data.slices[0].items");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-white blur-2xl absolute w-full h-full top-0 z-[-10] bg-opacity-60"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full bg-black bg-opacity-50 my-[100px] xl:my-[200px] px-6 py-10 z-30",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-center items-center text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-xl font-semibold lg:text-[38px]",
                                children: "傳統派報 x 平面設計"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "border-white border-b w-[80%] mt-3 mb-6 md:w-[60%] lg:2-[50%] lg:mt-6 xl:w-[30%]"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col only:items-start text-sm space-y-4 lg:text-base",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "從設計到派發"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "我們要讓您的設計貼滿大街小巷"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full p-10 lg:px-[120px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(slider, {
                                    logo: target
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center px-12 text-[12px] text-white leading-6 lg:text-lg",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "大和派報社於1997年投入廣告事業，25年派發廣告經驗，為順應時代變化，大和派報也不斷進步"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const sliderSection = (SliderSection);

// EXTERNAL MODULE: ./components/messageModal.tsx
var messageModal = __webpack_require__(5889);
// EXTERNAL MODULE: ./components/modal.tsx
var modal = __webpack_require__(7702);
;// CONCATENATED MODULE: ./components/mapModal.tsx


const mapModal = ({ isShow , setIsShow , image  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(modal/* default */.Z, {
        isShow: isShow,
        setIsShow: setIsShow,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `w-[90%] max-h-[80%] overflow-scroll fixed z-[500] top-[50%] left-[50%] translate-x-[-50%] translate-y-[-100%] md:translate-y-[-50%] p-10 ${isShow ? "" : "hidden"}`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    onClick: ()=>setIsShow(false),
                    className: "close cursor-pointer top-0"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: image,
                    alt: "",
                    className: "lg:max-h-[600px] mx-auto"
                })
            ]
        })
    });
};
/* harmony default export */ const components_mapModal = (mapModal);

;// CONCATENATED MODULE: ./components/areaMap.tsx




const AreaMap = ({ area  })=>{
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    const [targetImg, setTargetImg] = (0,external_react_.useState)("");
    const areaData = (0,external_lodash_.get)(area, "data.slices");
    const toObject = (arr)=>{
        let obj = {};
        arr.forEach((item)=>obj[item.primary.text] = item.primary.image.url);
        return obj;
    };
    const mapTarget = toObject(areaData);
    const handleClick = (city)=>{
        setTargetImg(mapTarget?.[city] || "");
        setIsOpen(true);
    };
    const Tag = ({ city , position  })=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: `/images/${city}.png`,
            alt: city,
            className: `absolute ${position} w-[12%] hover:scale-[1.15] ease-out duration-[400ms] cursor-pointer`,
            onClick: ()=>handleClick(city)
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative md:px-20 py-20 lg:flex",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative m-12 lg:m-16",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/citymap_outline.png",
                                alt: "map",
                                className: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "梓官",
                                position: "top-[22%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "楠梓",
                                position: "top-[33%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "左營",
                                position: "top-[38%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "鼓山",
                                position: "top-[44%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "三民",
                                position: "top-[50%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "鹽埕",
                                position: "top-[55%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "前金",
                                position: "top-[61%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "新興",
                                position: "top-[66.5%] left-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "前鎮",
                                position: "top-[73.5%] left-[3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "小港",
                                position: "top-[83%] left-[2%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "岡山",
                                position: "top-[2.5%] right-[25%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "橋頭",
                                position: "top-[12%] right-[26%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "大社",
                                position: "top-[19.5%] right-[17%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "仁武",
                                position: "top-[26.5%] right-[19%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "鳥松",
                                position: "top-[33.5%] right-[21%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "屏東",
                                position: "top-[43.5%] right-[-7%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "鳳山",
                                position: "top-[58%] right-[13%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "苓雅",
                                position: "top-[63.5%] right-[-3%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "大寮",
                                position: "top-[74%] right-[6%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "林園",
                                position: "top-[87%] right-[12%]"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative m-12 lg:m-16",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/specialmap_outline.png",
                                alt: "map",
                                className: ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "阿蓮",
                                position: "top-[-0.5%] left-[3%] lg:top-[0%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "路竹",
                                position: "top-[17%] left-[-3%] lg:top-[16.5%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "彌陀",
                                position: "top-[29.5%] left-[-3%] lg:top-[28%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "燕巢",
                                position: "top-[42%] left-[-2%] lg:top-[39.5%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "麟洛",
                                position: "top-[60%] left-[4%] lg:top-[57%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "萬丹",
                                position: "top-[67.5%] left-[3%] lg:top-[63.5%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "新園",
                                position: "top-[74.5%] left-[5%] lg:top-[70%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "東港",
                                position: "top-[90%] left-[4%] lg:top-[85%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "美濃",
                                position: "top-[14%] right-[3%] lg:top-[13%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "旗山",
                                position: "top-[27.5%] right-[16%] lg:top-[26%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "大樹",
                                position: "top-[36.5%] right-[16%] lg:top-[34%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "長治",
                                position: "top-[39%] right-[-2%] lg:top-[36.5%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "內埔",
                                position: "top-[51%] right-[-1%] lg:top-[48%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "竹田",
                                position: "top-[63%] right-[-1%] lg:top-[59%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "崁頂",
                                position: "top-[77.5%] right-[-3%] lg:top-[73%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "南洲",
                                position: "top-[84.5%] right-[-3%] lg:top-[79.5%]"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Tag, {
                                city: "林邊",
                                position: "top-[91.5%] right-[0%] lg:top-[86.5%]"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_mapModal, {
                isShow: isOpen,
                setIsShow: setIsOpen,
                image: targetImg
            })
        ]
    });
};
/* harmony default export */ const areaMap = (AreaMap);

// EXTERNAL MODULE: external "@emailjs/browser"
var browser_ = __webpack_require__(7163);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser_);
;// CONCATENATED MODULE: ./components/contactUs.tsx





const Input = ({ name , setValue , value , placeholder  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "text-end",
        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
            type: "text",
            name: name,
            value: value,
            required: true,
            onChange: (e)=>setValue(e),
            className: "border-b border-black pb-1 w-[100%] focus:outline-0 bg-transparent",
            placeholder: placeholder
        })
    });
};
const Contact = ({ area  })=>{
    const [isShow, setIsShow] = (0,external_react_.useState)(false);
    const [state, setState] = (0,external_react_.useState)({
        name: "",
        address: "",
        phone: "",
        area: "",
        amount: ""
    });
    const handleInputChange = (e)=>{
        setState((prev)=>({
                ...prev,
                [e.target.name]: e.target.value
            }));
    };
    const handleOnSubmit = (e)=>{
        e.preventDefault();
        browser_default().send("service_foq6w5s", "template_b08elrw", {
            ...state,
            lineId: "X",
            description: "X"
        }, "OIRayJLa7-LHweyyF").then(()=>setIsShow(true), (error)=>{
            console.log("err", error.text);
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-white bg-opacity-80",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(areaMap, {
                area: area
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "border-t border-black w-[90%] mx-auto"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                onSubmit: handleOnSubmit,
                className: "w-full my-[100px] px-10 py-12 md:mb-[160px] lg:px-40 flex flex-col space-y-16 lg:flex-row justify-center lg:justify-between lg:items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-[40px] font-extrabold lg:text-[48px]",
                                children: "Contact /"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "font-semibold",
                                children: "與我們取得聯繫"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col space-y-10 md:items-center lg:mr-10 lg:justify-end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-col space-y-4 md:items-start",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-6 xl:space-x-14",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-4 min-w-[250px]",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-col space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "",
                                                            children: "商家名稱 *"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                                            name: "name",
                                                            setValue: handleInputChange,
                                                            value: state.name,
                                                            placeholder: ""
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-col space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "",
                                                            children: "商家地址 *"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                                            name: "address",
                                                            setValue: handleInputChange,
                                                            value: state.address,
                                                            placeholder: ""
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-col space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "",
                                                            children: "聯絡電話 *"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                                            name: "phone",
                                                            setValue: handleInputChange,
                                                            value: state.phone,
                                                            placeholder: ""
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-4 min-w-[260px]",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-col space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "",
                                                            children: "欲派報的行政區 *"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                                            name: "area",
                                                            setValue: handleInputChange,
                                                            value: state.area,
                                                            placeholder: "服務範圍：全高雄及部分屏東地區"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-col space-y-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "",
                                                            children: "欲派發的數量 *"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                                            name: "amount",
                                                            setValue: handleInputChange,
                                                            value: state.amount,
                                                            placeholder: "可直接與我們聯繫，以取得派報地圖"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-center mt-10 relative",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "submit",
                                        value: "發送",
                                        className: "bg-black text-white rounded-3xl pl-3 pr-10 py-3 tracking-widest hover:scale-105 ease-out duration-300 cursor-pointer"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/plane.png",
                                        className: "absolute w-[25px] h-[25px] z-10 top-[12px] left-[52%] md:left-[58%]"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(messageModal/* default */.Z, {
                isShow: isShow,
                setIsShow: setIsShow
            })
        ]
    });
};
/* harmony default export */ const contactUs = (Contact);

;// CONCATENATED MODULE: ./container/Main/index.tsx





const MainIndex = ({ data  })=>{
    const { historyText , partnerLogo , area  } = data;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(main, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_history, {
                text: historyText
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sliderSection, {
                logo: partnerLogo
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(contactUs, {
                area: area
            })
        ]
    });
};
/* harmony default export */ const container_Main = (MainIndex);


/***/ }),

/***/ 7378:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Index),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_template__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6488);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(848);
/* harmony import */ var _lib_prismic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3899);
/* harmony import */ var _container_Main__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(652);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_prismic__WEBPACK_IMPORTED_MODULE_3__]);
_lib_prismic__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-nocheck





function Index({ data  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_template__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            header: data,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container_Main__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data
            })
        })
    });
}
async function getStaticProps({ preview =false , previewData  }) {
    const client = (0,_lib_prismic__WEBPACK_IMPORTED_MODULE_3__/* .createClient */ .e)({
        previewData
    });
    const headerImg = await client.getByUID("header", "logo");
    const historyText = await client.getByUID("history", "story");
    const partnerLogo = await client.getByUID("partnerLogo", "partnerlogo");
    const area = await client.getByUID("areamap", "area");
    return {
        props: {
            data: {
                headerImg,
                historyText,
                partnerLogo,
                area
            }
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@emailjs/browser");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 7444:
/***/ ((module) => {

module.exports = require("next/dist/server/web/spec-extension/cookies/index.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4582:
/***/ ((module) => {

module.exports = import("@prismicio/client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,122,676,664,899,0,889], () => (__webpack_exec__(7378)));
module.exports = __webpack_exports__;

})();