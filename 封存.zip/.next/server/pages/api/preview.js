"use strict";
(() => {
var exports = {};
exports.id = 157;
exports.ids = [157];
exports.modules = {

/***/ 7444:
/***/ ((module) => {

module.exports = require("next/dist/server/web/spec-extension/cookies/index.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4582:
/***/ ((module) => {

module.exports = import("@prismicio/client");;

/***/ }),

/***/ 8363:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ createClient)
/* harmony export */ });
/* unused harmony export repositoryName */
/* harmony import */ var _prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
/* harmony import */ var _prismicio_next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3139);
/* harmony import */ var _sm_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1226);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_client__WEBPACK_IMPORTED_MODULE_0__]);
_prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * The project's Prismic repository name.
 */ const repositoryName = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.getRepositoryName(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ .o);
/**
 * Route definitions for Prismic documents.
 */ const routes = [
    {
        type: "tag",
        path: "/gallery/:uid"
    },
    {
        type: "projectpost",
        path: "/gallery/:uid"
    }
];
/**
 * Creates a Prismic client for the project's repository. The client is used to
 * query content from the Prismic API.
 *
 * @param config - Configuration for the Prismic client.
 */ const createClient = ({ previewData , req , ...config } = {})=>{
    const client = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.createClient(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ .o, {
        routes,
        ...config
    });
    _prismicio_next__WEBPACK_IMPORTED_MODULE_2__/* .enableAutoPreviews */ .L({
        client,
        previewData,
        req
    });
    return client;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 863:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ preview)
/* harmony export */ });
/* harmony import */ var _prismicio_next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2965);
/* harmony import */ var _prismicio_next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(815);
/* harmony import */ var _lib_prismic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8363);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_prismic__WEBPACK_IMPORTED_MODULE_0__]);
_lib_prismic__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function preview(req, res) {
    const client = (0,_lib_prismic__WEBPACK_IMPORTED_MODULE_0__/* .createClient */ .e)({
        req
    });
    (0,_prismicio_next__WEBPACK_IMPORTED_MODULE_1__/* .setPreviewData */ .m)({
        req,
        res
    });
    await (0,_prismicio_next__WEBPACK_IMPORTED_MODULE_2__/* .redirectToPreviewURL */ .u)({
        req,
        res,
        client
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1226:
/***/ ((module) => {

module.exports = JSON.parse('{"o":"https://daher-site.prismic.io/api/v2"}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [254], () => (__webpack_exec__(863)));
module.exports = __webpack_exports__;

})();