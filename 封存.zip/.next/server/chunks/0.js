"use strict";
exports.id = 0;
exports.ids = [0];
exports.modules = {

/***/ 5620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Community = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "https://www.facebook.com/%E5%A4%A7%E5%92%8C%E6%B4%BE%E5%A0%B1-%E5%B9%B3%E9%9D%A2%E8%A6%96%E8%A6%BA%E8%A8%AD%E8%A8%88-109830355137782",
                target: "_blank",
                className: "w-[50px] h-[50px] flex justify-center items-center cursor-pointer",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/facebook.png",
                    alt: "",
                    className: "w-[30px] h-[30px]"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "https://www.instagram.com/daher.1997/",
                target: "_blank",
                className: "w-[50px] h-[50px] flex justify-center items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/instagram.png",
                    alt: "",
                    className: "w-[30px] h-[30px]"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "https://line.me/ti/p/~ohheyheyhey",
                target: "_blank",
                className: "w-[50px] h-[50px] flex justify-center items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/line.png",
                    alt: "",
                    className: "w-[30px] h-[30px]"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "https://shopee.tw/daher_design",
                target: "_blank",
                className: "w-[50px] h-[50px] flex justify-center items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/images/shopee.png",
                    alt: "",
                    className: "w-[36px] h-[36px]"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Community);


/***/ }),

/***/ 848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./lib/constants.ts
const EXAMPLE_PATH = "cms-prismic";
const CMS_NAME = "Prismic";
const CMS_URL = "https://prismic.io/";
const HOME_OG_IMAGE_URL = "https://og-image.vercel.app/Next.js%20Blog%20Example%20with%20**Prismic**.png?theme=light&md=1&fontSize=75px&images=https%3A%2F%2Fassets.vercel.com%2Fimage%2Fupload%2Ffront%2Fassets%2Fdesign%2Fnextjs-black-logo.svg&images=https%3A%2F%2Fi.imgur.com%2FGVmKYul.png&widths=undefined&widths=auto&heights=undefined&heights=100";

;// CONCATENATED MODULE: ./components/meta.tsx



function Meta() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                children: "大和派報社"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "icon",
                type: "image/png",
                href: "/images/icon.png"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "mask-icon",
                href: "/favicon/safari-pinned-tab.svg",
                color: "#000000"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                charSet: "UTF-8",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "alternate",
                type: "application/rss+xml",
                href: "/feed.xml"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "description",
                content: `da-her`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image",
                content: HOME_OG_IMAGE_URL
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/layout.tsx


function Layout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Meta, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "min-h-screen",
                children: /*#__PURE__*/ jsx_runtime_.jsx("main", {
                    children: children
                })
            })
        ]
    });
}


/***/ }),

/***/ 4915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_2__);



const SubscribeForm = ({ formClassName  })=>{
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleOnSubscribe = (e)=>{
        e.preventDefault();
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default().send("service_foq6w5s", "template_nsjj3r4", {
            email
        }, "OIRayJLa7-LHweyyF").then(()=>window.alert("已成功送出！"), (error)=>{
            console.log("err", error.text);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        className: formClassName,
        onSubmit: handleOnSubscribe,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "text",
                name: "subscribe",
                value: email,
                required: true,
                onChange: (e)=>setEmail(e.target.value),
                placeholder: "輸入信箱獲得最新資訊優惠",
                className: "text-white bg-transparent border-b border-white pb-1 w-full focus:outline-0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "submit",
                value: "OK",
                className: "bg-white rounded-lg px-1 absolute right-[2px] cursor-pointer"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubscribeForm);


/***/ }),

/***/ 6488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/container.tsx

function Container({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mx-auto",
        children: children
    });
}

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/community.tsx
var community = __webpack_require__(5620);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
;// CONCATENATED MODULE: ./components/header.tsx





function Header({ header  }) {
    const [isScrollDown, setIsScrollDown] = (0,external_react_.useState)(false);
    const logo = (0,external_lodash_.get)(header?.headerImg, "data.slices[0].items") || [];
    let lastPos = 0;
    (0,external_react_.useEffect)(()=>{
        const handleScrollDown = ()=>{
            let scrollTop = document.documentElement.scrollTop;
            if (scrollTop > lastPos) {
                setIsScrollDown(true);
            } else {
                setIsScrollDown(false);
            }
            lastPos = scrollTop;
        };
        window.addEventListener("scroll", handleScrollDown);
        return ()=>window.removeEventListener("scroll", handleScrollDown);
    }, []);
    const handleScroll = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `flex w-full justify-between items-center fixed top-0 z-30`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `w-full header-bg bg-cover fixed z-30 top-0 h-[180px] ${isScrollDown ? "hidden" : ""}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `border-b w-[48%] h-[100px] z-50 ${isScrollDown ? "hidden" : ""}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: `${logo[0] ? logo[0].name.url : ""}`,
                    alt: "logo",
                    className: "max-h-[75px] w-auto cursor-pointer mx-5 mt-6 mb-3 md:mx-10"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: handleScroll,
                className: `border-b w-[48%] flex justify-end z-50 ${isScrollDown ? "hidden" : ""}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: `${logo[1] ? logo[1].name.url : ""}`,
                    alt: "logo",
                    className: "h-[75px] cursor-pointer mx-5 my-3 md:mx-10"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `fixed z-50 ${isScrollDown ? "hidden" : ""}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: "nav-box",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "checkbox",
                            id: "menu",
                            className: "lg:hidden"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            htmlFor: "menu",
                            className: "line lg:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "menu"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "menu-list lg:w-full lg:top-[50px] lg:h-[120px] lg:bg-transparent",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "lg:flex lg:space-y-0 lg:space-x-3 lg:!pt-[60px] lg:!ml-[36px] cursor-pointer tracking-[3px] text-lg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/about",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "my-5 lg:!w-auto hover:scale-[1.05] lg:hover:scale-[1.15] ease-out duration-300",
                                                onClick: handleScroll,
                                                children: [
                                                    "．派報",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "text-[6px] tracking-[1px]",
                                                        children: "ABOUT"
                                                    }),
                                                    "．"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/gallery/all",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "my-5 lg:!w-auto hover:scale-[1.05] lg:hover:scale-[1.15] ease-out duration-300",
                                                children: [
                                                    "．作品集",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "text-[6px] tracking-[1px]",
                                                        children: "WORKS"
                                                    }),
                                                    "．"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/product/all",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "my-5 lg:!w-auto hover:scale-[1.05] lg:hover:scale-[1.15] ease-out duration-300",
                                                children: [
                                                    "．商品",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "text-[6px] tracking-[1px]",
                                                        children: "PRODUCT"
                                                    }),
                                                    "．"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "my-5 lg:!w-auto hover:scale-[1.05] lg:hover:scale-[1.15] ease-out duration-300",
                                                children: [
                                                    "．聯絡我們",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "text-[6px] tracking-[1px]",
                                                        children: "CONTACT"
                                                    }),
                                                    "．"
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex space-x-10 justify-center mt-[150px]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(community/* default */.Z, {})
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden lg:flex lg:flex-col lg:items-center lg:fixed lg:right-[14px] lg:top-[140px] lg:space-y-6 xl:mr-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[100px] w-[2px] bg-white lg:h-[120px]"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "space-y-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(community/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[100px] w-[2px] bg-white xl:h-[120px]"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "arrow-body mr-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "arrow"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "arrow"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/banner.tsx


const Banner = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[102%] h-[105vh] fixed top-[-20px] left-[-12px] z-[-100] banner bg-cover"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed z-[-60] banner-circle1 bg-cover w-[1100px] h-[1100px] top-[-500px] left-[-700px] opacity-70 scale-110 md:left-[-480px] lg:top-[-400px] "
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed z-[-50] banner-circle1 bg-cover w-[1100px] h-[1100px] top-[-500px] left-[-700px] opacity-90 md:left-[-480px] lg:top-[-400px]"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed z-[-70] banner-circle2 bg-cover w-[600px] h-[600px] top-[580px] left-[60px] opacity-90 md:left-[260px] lg:top-[600px] lg:left-[300px]"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed z-[-80] banner-circle2 bg-cover w-[600px] h-[600px] top-[580px] left-[60px] opacity-60 scale-110 md:left-[260px] lg:top-[600px] lg:left-[300px]"
            })
        ]
    });
};
/* harmony default export */ const banner = (Banner);

// EXTERNAL MODULE: ./components/subscribeForm.tsx
var subscribeForm = __webpack_require__(4915);
;// CONCATENATED MODULE: ./components/footer.tsx


const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "bg-[#141414]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "py-6 px-12 flex flex-col items-start lg:flex-row lg:py-[40px] lg:items-center lg:px-[100px] xl:pr-[200px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end mb-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            alt: "footer-logo",
                            src: "/images/icon.png",
                            className: "w-[60px] lg:mr-10"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "space-y-14 lg:flex lg:space-y-0 lg:flex-1 lg:justify-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-start items-start text-white space-y-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "TEL"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-gray-300",
                                                href: "tel:07-7663777",
                                                children: "07-766-3777"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "Add"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-gray-300",
                                                href: "https://goo.gl/maps/SVAwcAfbyXchNotN8",
                                                target: "_blank",
                                                children: "高雄市鳳山區新強路135號"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "font-bold",
                                                children: "email"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "text-gray-300",
                                                href: "mailto:daher.advertise@gmail.com",
                                                children: "daher.advertise@gmail.com"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col lg:flex-col justify-start items-start text-white space-y-2 lg:space-y-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "font-bold",
                                        children: "Follow us"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex space-x-4 text-gray-300 lg:flex-col lg:space-x-0 lg:space-y-1",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://www.instagram.com/daher.1997/",
                                                target: "_blank",
                                                children: "Instagram"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://www.facebook.com/%E5%A4%A7%E5%92%8C%E6%B4%BE%E5%A0%B1-%E5%B9%B3%E9%9D%A2%E8%A6%96%E8%A6%BA%E8%A8%AD%E8%A8%88-109830355137782",
                                                target: "_blank",
                                                children: "Facebook"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "",
                                                children: "Line"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(subscribeForm/* default */.Z, {
                formClassName: "relative w-[70%] py-6 px-12 my-14 md:w-1/2 lg:w-1/4 lg:mx-auto lg:py-1 lg:mt-1"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-white opacity-10 w-full text-center pb-6",
                children: "@Da-Her Yuan Design"
            })
        ]
    });
};
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: ./components/template.tsx





function Layout({ children , header  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Header, {
                    header: header
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(banner, {}),
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
            ]
        })
    });
}


/***/ })

};
;