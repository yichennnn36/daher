exports.id = 502;
exports.ids = [502];
exports.modules = {

/***/ 502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "N": () => (/* binding */ PrismicPreview)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9332);
// EXTERNAL MODULE: ./node_modules/@prismicio/next/dist/_node_modules/@prismicio/client/dist/cookie.js
var dist_cookie = __webpack_require__(283);
;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/lib/getPrismicPreviewCookie.js

const readValue = (value) => {
  return value.replace(/%3B/g, ";");
};
const getPrismicPreviewCookie = (cookieJar) => {
  const cookies = cookieJar.split("; ");
  let value;
  for (const cookie of cookies) {
    const parts = cookie.split("=");
    const name = readValue(parts[0]).replace(/%3D/g, "=");
    if (name === dist_cookie/* preview */.R) {
      value = readValue(parts.slice(1).join("="));
      continue;
    }
  }
  return value;
};

//# sourceMappingURL=getPrismicPreviewCookie.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/lib/getPreviewCookieRepositoryName.js
const getPreviewCookieRepositoryName = (previewCookie) => {
  return (decodeURIComponent(previewCookie).match(/"(.+).prismic.io"/) || [])[1];
};

//# sourceMappingURL=getPreviewCookieRepositoryName.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/PrismicPreviewClient.js
'use client';
'use client';





function PrismicPreviewClient({ repositoryName, updatePreviewURL = "/api/preview", exitPreviewURL = "/api/exit-preview" }) {
  let isAppRouter = true;
  let isPreviewMode = false;
  let basePath = "";
  let refresh;
  try {
    const router = (0,router_.useRouter)();
    isAppRouter = false;
    basePath = router.basePath;
    isPreviewMode = router.isPreview;
    refresh = () => router.replace(router.asPath, void 0, { scroll: false });
  } catch {
    const router = (0,navigation.useRouter)();
    refresh = router.refresh;
  }
  (0,external_react_.useEffect)(() => {
    const startPreviewMode = async () => {
      const resolvedUpdatePreviewURL = basePath + updatePreviewURL;
      const res = await globalThis.fetch(resolvedUpdatePreviewURL);
      if (res.redirected) {
        refresh();
      } else {
        console.error(`[<PrismicPreview>] Failed to start or update Preview Mode using the "${resolvedUpdatePreviewURL}" API endpoint. Does it exist?`);
      }
    };
    const handlePrismicPreviewUpdate = async (event) => {
      event.preventDefault();
      if (isAppRouter) {
        refresh();
      } else {
        await startPreviewMode();
      }
    };
    const handlePrismicPreviewEnd = async (event) => {
      event.preventDefault();
      if (isAppRouter) {
        refresh();
      } else {
        const resolvedExitPreviewURL = basePath + exitPreviewURL;
        const res = await globalThis.fetch(resolvedExitPreviewURL);
        if (res.ok) {
          refresh();
        } else {
          console.error(`[<PrismicPreview>] Failed to exit Preview Mode using the "${resolvedExitPreviewURL}" API endpoint. Does it exist?`);
        }
      }
    };
    window.addEventListener("prismicPreviewUpdate", handlePrismicPreviewUpdate);
    window.addEventListener("prismicPreviewEnd", handlePrismicPreviewEnd);
    if (!isPreviewMode) {
      const prismicPreviewCookie = getPrismicPreviewCookie(globalThis.document.cookie);
      if (prismicPreviewCookie) {
        const locationIsDescendantOfBasePath = window.location.href.startsWith(window.location.origin + basePath);
        const prismicPreviewCookieRepositoryName = getPreviewCookieRepositoryName(prismicPreviewCookie);
        if (locationIsDescendantOfBasePath && prismicPreviewCookieRepositoryName === repositoryName) {
          startPreviewMode();
        }
      }
    }
    return () => {
      window.removeEventListener("prismicPreviewUpdate", handlePrismicPreviewUpdate);
      window.removeEventListener("prismicPreviewEnd", handlePrismicPreviewEnd);
    };
  }, [
    basePath,
    exitPreviewURL,
    isAppRouter,
    isPreviewMode,
    refresh,
    repositoryName,
    updatePreviewURL
  ]);
  return null;
}

//# sourceMappingURL=PrismicPreviewClient.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/_node_modules/@prismicio/client/dist/errors/PrismicError.js
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class PrismicError extends Error {
  constructor(message = "An invalid API response was returned", url, response) {
    super(message);
    __publicField(this, "url");
    __publicField(this, "response");
    this.url = url;
    this.response = response;
  }
}

//# sourceMappingURL=PrismicError.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/_node_modules/@prismicio/client/dist/isRepositoryName.js
const isRepositoryName = (input) => {
  return /^[a-zA-Z0-9][-a-zA-Z0-9]{2,}[a-zA-Z0-9]$/.test(input);
};

//# sourceMappingURL=isRepositoryName.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/_node_modules/@prismicio/client/dist/getToolbarSrc.js


const getToolbarSrc = (repositoryName) => {
  if (isRepositoryName(repositoryName)) {
    return `https://static.cdn.prismic.io/prismic.js?new=true&repo=${repositoryName}`;
  } else {
    throw new PrismicError(`An invalid Prismic repository name was given: ${repositoryName}`, void 0, void 0);
  }
};

//# sourceMappingURL=getToolbarSrc.js.map

;// CONCATENATED MODULE: ./node_modules/@prismicio/next/dist/PrismicPreview.js




function PrismicPreview({ repositoryName, children, ...props }) {
  const toolbarSrc = getToolbarSrc(repositoryName);
  return (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, { children: [children, (0,jsx_runtime_.jsx)(PrismicPreviewClient, { repositoryName, ...props }), (0,jsx_runtime_.jsx)((script_default()), { src: toolbarSrc, strategy: "lazyOnload" })] });
}

//# sourceMappingURL=PrismicPreview.js.map


/***/ }),

/***/ 2308:
/***/ ((module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.bailoutToClientRendering = bailoutToClientRendering;
var _dynamicNoSsr = __webpack_require__(4564);
var _staticGenerationAsyncStorage = __webpack_require__(2437);
function bailoutToClientRendering() {
    const staticGenerationStore = _staticGenerationAsyncStorage.staticGenerationAsyncStorage && "getStore" in _staticGenerationAsyncStorage.staticGenerationAsyncStorage ? _staticGenerationAsyncStorage.staticGenerationAsyncStorage == null ? void 0 : _staticGenerationAsyncStorage.staticGenerationAsyncStorage.getStore() : _staticGenerationAsyncStorage.staticGenerationAsyncStorage;
    if (staticGenerationStore == null ? void 0 : staticGenerationStore.forceStatic) {
        return true;
    }
    if (staticGenerationStore == null ? void 0 : staticGenerationStore.isStaticGeneration) {
        (0, _dynamicNoSsr).suspense();
    }
    return false;
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=bailout-to-client-rendering.js.map


/***/ }),

/***/ 3897:
/***/ ((module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.useSearchParams = useSearchParams;
exports.usePathname = usePathname;
Object.defineProperty(exports, "ServerInsertedHTMLContext", ({
    enumerable: true,
    get: function() {
        return _serverInsertedHtml.ServerInsertedHTMLContext;
    }
}));
Object.defineProperty(exports, "useServerInsertedHTML", ({
    enumerable: true,
    get: function() {
        return _serverInsertedHtml.useServerInsertedHTML;
    }
}));
exports.useRouter = useRouter;
exports.useSelectedLayoutSegments = useSelectedLayoutSegments;
exports.useSelectedLayoutSegment = useSelectedLayoutSegment;
Object.defineProperty(exports, "redirect", ({
    enumerable: true,
    get: function() {
        return _redirect.redirect;
    }
}));
Object.defineProperty(exports, "notFound", ({
    enumerable: true,
    get: function() {
        return _notFound.notFound;
    }
}));
var _react = __webpack_require__(6689);
var _appRouterContext = __webpack_require__(3280);
var _hooksClientContext = __webpack_require__(9274);
var _bailoutToClientRendering = __webpack_require__(2308);
var _serverInsertedHtml = __webpack_require__(3349);
var _redirect = __webpack_require__(761);
var _notFound = __webpack_require__(8739);
const INTERNAL_URLSEARCHPARAMS_INSTANCE = Symbol("internal for urlsearchparams readonly");
function readonlyURLSearchParamsError() {
    return new Error("ReadonlyURLSearchParams cannot be modified");
}
class ReadonlyURLSearchParams {
    [Symbol.iterator]() {
        return this[INTERNAL_URLSEARCHPARAMS_INSTANCE][Symbol.iterator]();
    }
    append() {
        throw readonlyURLSearchParamsError();
    }
    delete() {
        throw readonlyURLSearchParamsError();
    }
    set() {
        throw readonlyURLSearchParamsError();
    }
    sort() {
        throw readonlyURLSearchParamsError();
    }
    constructor(urlSearchParams){
        // Since `new Headers` uses `this.append()` to fill the headers object ReadonlyHeaders can't extend from Headers directly as it would throw.
        this[INTERNAL_URLSEARCHPARAMS_INSTANCE] = urlSearchParams;
        this.entries = urlSearchParams.entries.bind(urlSearchParams);
        this.forEach = urlSearchParams.forEach.bind(urlSearchParams);
        this.get = urlSearchParams.get.bind(urlSearchParams);
        this.getAll = urlSearchParams.getAll.bind(urlSearchParams);
        this.has = urlSearchParams.has.bind(urlSearchParams);
        this.keys = urlSearchParams.keys.bind(urlSearchParams);
        this.values = urlSearchParams.values.bind(urlSearchParams);
        this.toString = urlSearchParams.toString.bind(urlSearchParams);
    }
}
function useSearchParams() {
    const searchParams = (0, _react).useContext(_hooksClientContext.SearchParamsContext);
    const readonlySearchParams = (0, _react).useMemo(()=>{
        return new ReadonlyURLSearchParams(searchParams || new URLSearchParams());
    }, [
        searchParams
    ]);
    if ((0, _bailoutToClientRendering).bailoutToClientRendering()) {
        // TODO-APP: handle dynamic = 'force-static' here and on the client
        return readonlySearchParams;
    }
    if (!searchParams) {
        throw new Error("invariant expected search params to be mounted");
    }
    return readonlySearchParams;
}
function usePathname() {
    return (0, _react).useContext(_hooksClientContext.PathnameContext);
}
function useRouter() {
    const router = (0, _react).useContext(_appRouterContext.AppRouterContext);
    if (router === null) {
        throw new Error("invariant expected app router to be mounted");
    }
    return router;
}
// TODO-APP: handle parallel routes
function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first = true, segmentPath = []) {
    let node;
    if (first) {
        // Use the provided parallel route key on the first parallel route
        node = tree[1][parallelRouteKey];
    } else {
        // After first parallel route prefer children, if there's no children pick the first parallel route.
        const parallelRoutes = tree[1];
        var _children;
        node = (_children = parallelRoutes.children) != null ? _children : Object.values(parallelRoutes)[0];
    }
    if (!node) return segmentPath;
    const segment = node[0];
    const segmentValue = Array.isArray(segment) ? segment[1] : segment;
    if (!segmentValue) return segmentPath;
    segmentPath.push(segmentValue);
    return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
}
function useSelectedLayoutSegments(parallelRouteKey = "children") {
    const { tree  } = (0, _react).useContext(_appRouterContext.LayoutRouterContext);
    return getSelectedLayoutSegmentPath(tree, parallelRouteKey);
}
function useSelectedLayoutSegment(parallelRouteKey = "children") {
    const selectedLayoutSegments = useSelectedLayoutSegments(parallelRouteKey);
    if (selectedLayoutSegments.length === 0) {
        return null;
    }
    return selectedLayoutSegments[0];
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=navigation.js.map


/***/ }),

/***/ 8739:
/***/ ((module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.notFound = notFound;
exports.NOT_FOUND_ERROR_CODE = void 0;
const NOT_FOUND_ERROR_CODE = "NEXT_NOT_FOUND";
exports.NOT_FOUND_ERROR_CODE = NOT_FOUND_ERROR_CODE;
function notFound() {
    // eslint-disable-next-line no-throw-literal
    const error = new Error(NOT_FOUND_ERROR_CODE);
    error.digest = NOT_FOUND_ERROR_CODE;
    throw error;
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=not-found.js.map


/***/ }),

/***/ 761:
/***/ ((module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.redirect = redirect;
exports.REDIRECT_ERROR_CODE = void 0;
const REDIRECT_ERROR_CODE = "NEXT_REDIRECT";
exports.REDIRECT_ERROR_CODE = REDIRECT_ERROR_CODE;
function redirect(url) {
    // eslint-disable-next-line no-throw-literal
    const error = new Error(REDIRECT_ERROR_CODE);
    error.digest = REDIRECT_ERROR_CODE + ";" + url;
    throw error;
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=redirect.js.map


/***/ }),

/***/ 4564:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = NoSSR;
exports.suspense = suspense;
var _interop_require_default = (__webpack_require__(2648)/* ["default"] */ .Z);
var _react = _interop_require_default(__webpack_require__(6689));
var _noSsrError = __webpack_require__(7342);
function NoSSR({ children  }) {
    if (true) {
        suspense();
    }
    return children;
}
function suspense() {
    const error = new Error(_noSsrError.NEXT_DYNAMIC_NO_SSR_CODE);
    error.digest = _noSsrError.NEXT_DYNAMIC_NO_SSR_CODE;
    throw error;
} //# sourceMappingURL=dynamic-no-ssr.js.map


/***/ }),

/***/ 9332:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3897)


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ })

};
;