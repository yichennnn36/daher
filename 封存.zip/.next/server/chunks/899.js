"use strict";
exports.id = 899;
exports.ids = [899];
exports.modules = {

/***/ 3899:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ repositoryName),
/* harmony export */   "e": () => (/* binding */ createClient)
/* harmony export */ });
/* harmony import */ var _prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
/* harmony import */ var _prismicio_next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5596);
/* harmony import */ var _sm_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(125);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_client__WEBPACK_IMPORTED_MODULE_0__]);
_prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * The project's Prismic repository name.
 */ const repositoryName = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.getRepositoryName(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ .o);
/**
 * Route definitions for Prismic documents.
 */ const routes = [
    {
        type: "tag",
        path: "/gallery/:uid"
    },
    {
        type: "projectpost",
        path: "/gallery/:uid"
    }
];
/**
 * Creates a Prismic client for the project's repository. The client is used to
 * query content from the Prismic API.
 *
 * @param config - Configuration for the Prismic client.
 */ const createClient = ({ previewData , req , ...config } = {})=>{
    const client = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.createClient(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ .o, {
        routes,
        ...config
    });
    _prismicio_next__WEBPACK_IMPORTED_MODULE_2__/* .enableAutoPreviews */ .L({
        client,
        previewData,
        req
    });
    return client;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 125:
/***/ ((module) => {

module.exports = JSON.parse('{"o":"https://daher-site.prismic.io/api/v2"}');

/***/ })

};
;